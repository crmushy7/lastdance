<template>
  <div>
    <h1>Thanks for your feedback!</h1>
    <NuxtLink to="/">Home</NuxtLink>
  </div>
</template>
